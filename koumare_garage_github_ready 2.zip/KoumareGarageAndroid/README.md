# Koumare Garage V1
Application Android hors connexion pour remplacer le cahier de l'atelier.

Fonctions : réparations, revenus, dépenses, salaires variables, historique, calcul du résultat et stockage local sur le téléphone.

## Compiler
Ouvrir ce dossier dans Android Studio puis : Build > Generate App Bundle / APK > Generate APK.
Le fichier APK sera créé dans `app/build/outputs/apk/debug/` pour une compilation debug.
