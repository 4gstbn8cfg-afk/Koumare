package com.koumaregarage.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import org.json.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout root, content; SharedPreferences sp; JSONArray ops; TextView balance, income, expense, salary;
  int blue=Color.rgb(37,99,235), dark=Color.rgb(17,24,39), bg=Color.rgb(244,246,248);
  public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("data",0);load();build();showDashboard();}
  void load(){try{ops=new JSONArray(sp.getString("ops","[]"));}catch(Exception e){ops=new JSONArray();}}
  void save(){sp.edit().putString("ops",ops.toString()).apply();}
  TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(dark);t.setPadding(20,16,20,16);return t;}
  Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
  void build(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);setContentView(root);
    TextView head=tv("Koumare Garage",24);head.setTextColor(Color.WHITE);head.setBackgroundColor(dark);head.setGravity(Gravity.CENTER_VERTICAL);root.addView(head,new LinearLayout.LayoutParams(-1,70));
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout nav=new LinearLayout(this);nav.setPadding(4,4,4,4);nav.setBackgroundColor(Color.WHITE);
    String[] ns={"Accueil","Réparation","Dépense","Salaire","Historique"};for(String n:ns){Button x=btn(n);x.setOnClickListener(v->{if(n.equals("Accueil"))showDashboard();else if(n.equals("Réparation"))repairForm();else if(n.equals("Dépense"))moneyForm("Dépense");else if(n.equals("Salaire"))moneyForm("Salaire");else history();});nav.addView(x,new LinearLayout.LayoutParams(0,65,1));}root.addView(nav);
  }
  void clear(){content.removeAllViews();}
  void showDashboard(){clear();content.addView(tv("Tableau de bord",26)); long in=sum("Revenu"), ex=sum("Dépense"), sal=sum("Salaire");
    content.addView(tv("Revenus : "+fmt(in)+" FCFA",19));content.addView(tv("Dépenses : "+fmt(ex)+" FCFA",19));content.addView(tv("Salaires : "+fmt(sal)+" FCFA",19));content.addView(tv("Résultat : "+fmt(in-ex-sal)+" FCFA",22));
    content.addView(tv("Réparations enregistrées : "+count("Réparation"),18));content.addView(tv("\nToutes les données sont conservées localement sur ce téléphone.",15));
  }
  long sum(String type){long s=0;for(int i=0;i<ops.length();i++)try{JSONObject o=ops.getJSONObject(i);if(type.equals(o.getString("type")))s+=o.optLong("amount");}catch(Exception e){}return s;}
  int count(String type){int n=0;for(int i=0;i<ops.length();i++)try{if(type.equals(ops.getJSONObject(i).getString("type")))n++;}catch(Exception e){}return n;}
  String fmt(long n){return String.format(Locale.FRANCE,"%,d",n).replace(',', ' ');}
  EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setPadding(16,10,16,10);content.addView(e,new LinearLayout.LayoutParams(-1,60));return e;}
  void repairForm(){clear();content.addView(tv("Nouvelle réparation",25));EditText c=input("Client");EditText v=input("Véhicule / modèle");EditText work=input("Travail effectué / panne");EditText tech=input("Réparateur");EditText amount=input("Montant encaissé (FCFA)");amount.setInputType(2);Button b=btn("Enregistrer");content.addView(b);b.setOnClickListener(x->{if(c.getText().length()==0||amount.getText().length()==0){toast("Client et montant obligatoires");return;}add("Réparation",amount.getText().toString(),c.getText()+" — "+v.getText()+" — "+work.getText()+" — "+tech.getText());toast("Réparation enregistrée");showDashboard();});}
  void moneyForm(String type){clear();content.addView(tv(type,25));EditText who=input(type.equals("Salaire")?"Personne / réparateur":"Catégorie (nourriture, matériel, transport...)");EditText desc=input("Description");EditText amount=input("Montant (FCFA)");amount.setInputType(2);Button b=btn("Enregistrer");content.addView(b);b.setOnClickListener(x->{if(amount.getText().length()==0){toast("Montant obligatoire");return;}add(type,amount.getText().toString(),who.getText()+" — "+desc.getText());toast(type+" enregistré");showDashboard();});}
  void add(String type,String a,String desc){try{JSONObject o=new JSONObject();o.put("type",type);o.put("amount",Long.parseLong(a));o.put("desc",desc);o.put("date",new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.FRANCE).format(new Date()));ops.put(o);save();}catch(Exception e){toast("Erreur d'enregistrement");}}
  void history(){clear();content.addView(tv("Historique",25));for(int i=ops.length()-1;i>=0;i--)try{JSONObject o=ops.getJSONObject(i);content.addView(tv(o.getString("date")+"\n"+o.getString("type")+" — "+fmt(o.getLong("amount"))+" FCFA\n"+o.getString("desc"),15));}catch(Exception e){} if(ops.length()==0)content.addView(tv("Aucune opération enregistrée.",17));}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
