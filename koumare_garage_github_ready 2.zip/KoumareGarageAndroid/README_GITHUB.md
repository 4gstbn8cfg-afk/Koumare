# Koumare Garage — compilation Android depuis un iPhone

1. Crée un dépôt GitHub vide.
2. Envoie tout le contenu de ce dossier à la racine du dépôt (notamment `app`, `gradle.properties`, `settings.gradle`, `build.gradle` et `.github`).
3. Va dans **Actions** puis lance **Build Koumare Garage APK** avec **Run workflow**.
4. Quand le workflow est terminé, ouvre l'exécution et télécharge l'artifact **KoumareGarage-debug-apk**.
5. Décompresse l'artifact et récupère `app-debug.apk`.
6. Envoie l'APK sur ton Android et installe-le. Si Android demande l'autorisation d'installer des applications provenant de cette source, autorise temporairement ton gestionnaire de fichiers/navigateur.

Aucun ordinateur n'est nécessaire pour la compilation : GitHub Actions fait le build dans le cloud.
